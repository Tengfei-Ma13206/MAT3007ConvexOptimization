cvx_begin
variable x(10)
minimize sum(x)
subject to
x <= 1
x >= 0
x(1) + x(6) >= 1
x(1) + x(5) >= 1
x(1) + x(2) >= 1
x(6) + x(9) >= 1
x(6) + x(8) >= 1
x(5) + x(10) >= 1
x(5) + x(4) >= 1
x(2) + x(7) >= 1
x(2) + x(3) >= 1
x(10) + x(7) >= 1
x(10) + x(8) >= 1
x(7) + x(9) >= 1
x(4) + x(9) >= 1
x(4) + x(3) >= 1
x(3) + x(8) >= 1
cvx_end