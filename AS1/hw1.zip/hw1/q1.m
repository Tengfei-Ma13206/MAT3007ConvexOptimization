cvx_begin
variables x1 x2
    maximize (7.8 * x1 + 7.1 * x2)
    subject to
        1/4 * x1 + 1/3 * x2 <= 90
        1/8 * x1 + 1/3 * x2 <= 80
        x1 >= 0
        x2 >= 0
cvx_end