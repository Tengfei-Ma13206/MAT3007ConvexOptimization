clear;
clc;
X = [-4 -4 -4 -2 -2 2 2 4 4 4;
     -4 0 4 -4 4 -4 4 -4 0 4];
x = [0;0];

tol = 10^(-5);%for gradient descent
tol_search = 10^(-6);
maxit = 100;
a = 2;

for i = 1:10
    x(1) = X(1,i);
    x(2) = X(2,i);
    plot(x(1),x(2),'*');%'*' stands for initial points
    hold on;
    while norm(gradient(x)) > tol
        xl = x;
        xr = x - a * gradient(x);
        phi = (3 - sqrt(5)) / 2;
    
        it = 0;
        while norm(xr - xl) > tol_search && it < maxit
            x1 = phi * xr + (1 - phi) * xl;
            x2 = phi * xl + (1 - phi) * xr;
            if  f(x1) >  f(x2)
                xl = x1;
            else
                xr = x2;
            end
            it = it + 1;
        end
        xtemp = (xr + xl) / 2;
        
        plot([x(1), xtemp(1)], [x(2), xtemp(2)], '-');
        hold on;
        x = xtemp;
    end
    plot(x(1),x(2),'o');%o stands for limit points
    hold on;
end
func = @(m,n) m^4 + 2*(m-n)*m^2+4*n^2;
fcontour(func,'--');
hold on;
txt = {'* for initial points','o for limit points'};
text(3,5.5,txt);
hold on;