clear;clc;
x = [-1;-0.5];
tol = 10^(-7);
sigma = 0.5;
gamma = 10^(-4);
gamma1 = 10^(-6);
gamma2 = 0.1;

alwaysUtilizeNewtonDirection = 1;
alwayUseFullStepSize = 1;
iter = 0;
while norm(gradient(x)) > tol
    s = -(hessian(x))\gradient(x);
    if -gradient(x)'*s >= gamma1*min([1;(norm(s))^(gamma2)])*(norm(s))^2
        d = s;
    else
        d = -gradient(x);
        alwaysUtilizeNewtonDirection = 0;
    end
    t = 1;
    xtemp = x + t * d;
    while f(xtemp) >= f(x) + gamma * t * gradient(x)' * d
        t = t * sigma;
        xtemp = x + t * d;
        alwayUseFullStepSize = 0;
    end
    x = xtemp;
    iter = iter + 1;
end

disp('globalized Newton method: ')
disp('x = ')
disp(x)
disp('the number of iterations')
disp(iter)
if alwaysUtilizeNewtonDirection == 0
    disp('the Newton method does not always utilize the Newton direction');
else
    disp('the Newton method always utilizes the Newton direction');
end

if alwayUseFullStepSize == 0
    disp('the method does not always use full step size');
else
    disp('the method always uses full step size');
end
