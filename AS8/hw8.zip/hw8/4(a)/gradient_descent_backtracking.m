clear;clc;
x = [-1; -0.5]; 
tol = 10^(-7); 
gamma = 10^(-4);
sigma = 0.5;
iter = 0;
while norm(gradient(x)) > tol     
     d = gradient(x);
     t = 1;
     xtemp = x - t * d;
     while f(xtemp) >= f(x) - gamma * t * gradient(x)' * d
         t = t * sigma;
         xtemp = x - t * d;
     end
    x = xtemp; 
    iter = iter + 1;
end
disp('backtracking: ')
disp('x = ')
disp(x)
disp('the number of iterations')
disp(iter)