function y = gradient(x)
y1 = 200*(x(2) - x(1)^2)*(-2*x(1)) - 2*(1-x(1));
y2 = 200*(x(2) - x(1)^2);
y = [y1;y2];