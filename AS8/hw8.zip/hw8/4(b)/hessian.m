function y = hessian(x)
y = zeros(2,2);
y(1,1) = 12*x(1)^2 + 12 * x(1) - 4*x(2);
y(1,2) = -4*x(1);
y(2,1) = -4*x(1);
y(2,2) = 8;