function y = gradient(x)
y1 = 4*x(1)^3 + 6*x(1)^2 -4*x(1)*x(2);
y2 = -2*x(1)^2 + 8*x(2);
y = [y1;y2];