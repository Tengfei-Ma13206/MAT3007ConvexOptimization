clear;clc;
X = [-4 -4 -4 -2 -2 2 2 4 4 4;
     -4 0 4 -4 4 -4 4 -4 0 4];
x = [0;0];

tol = 10^(-5); 
gamma = 0.1;
sigma = 0.5;

for i = 1:10
    x(1) = X(1, i);
    x(2) = X(2, i);
    plot(x(1),x(2),'*');%'*' stands for initial points
    hold on;
    while norm(gradient(x)) > tol     
         d = gradient(x);
         if abs(d(1)) > abs(d(2))
             d(2) = 0;
         else
             d(1) = 0;
         end
   
         t = 1;
         xtemp = x - t * d;
         while f(xtemp) >= f(x) - gamma * t * gradient(x)' * d
             t = t * sigma;
             xtemp = x - t * d;
         end
        plot([x(1), xtemp(1)], [x(2), xtemp(2)], '-');
        hold on;
        x = xtemp;
    end
    plot(x(1),x(2),'o');%o stands for limit points
    hold on;
end
func = @(m,n) m^4 + 2*(m-n)*m^2+4*n^2;
fcontour(func,'--');
hold on;
txt = {'* for initial points','o for limit points'};
text(3,5.5,txt);
hold on;