% Bisection method
xl = 0;
xr = 1;
iter_bi = 0;
while xr - xl > 10^(-5) 
    xm = 0.5 * (xl + xr);
    if derivative(xm) > 0 
        xr = xm;
    else
        xl = xm;
    end
    iter_bi = iter_bi + 1;
end
disp('the solution by bisection is ')
disp(xm)
disp('the number of iterations by bisection is')
disp(iter_bi)

%% Golden section method
xl = 0;
xr = 1;
phi = (3 - sqrt(5)) / 2;
iter_gold = 0;
while xr - xl > 10^(-5)
    x1 = phi * xr + (1 - phi) * xl;
    x2 = phi * xl + (1 - phi) * xr;
    if  f(x1) <  f(x2)
        xr = x2;
    else
        xl = x1;
    end
    iter_gold = iter_gold + 1;
end
disp('the solution by golden section is ')
disp(0.5*(xl + xr))
disp('the number of iterations by golden section is')
disp(iter_gold)