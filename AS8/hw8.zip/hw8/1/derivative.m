function y = derivative(x)
y = -exp(-x) + sin(x);