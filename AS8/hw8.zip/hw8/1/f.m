function y = f(x)
y = exp(-x) - cos(x);