clear;clc;
x = [3; -3]; 
tol = 10^(-5); 
gamma = 0.1;
sigma = 0.5;

iter = 0;
while norm(gradient(x)) > tol     
     d = gradient(x);
     t = 1;
     
     xtemp = x - t * d;
     while f(xtemp) >= f(x) - gamma * t * gradient(x)' * d
         t = t * sigma;
         xtemp = x - t * d;
     end
    iter = iter + 1;
    x = xtemp; 
end
disp('backtracking: ')
disp('x = ')
disp(x)
disp('the number of iterations')
disp(iter)