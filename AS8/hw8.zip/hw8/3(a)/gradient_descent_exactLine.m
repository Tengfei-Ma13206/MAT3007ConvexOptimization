clear;
clc;
x = [3; -3];
tol = 10^(-5);
maxit = 100;
iter = 0;
a = 2;
while norm(gradient(x)) > tol
 % Doing exact line search
    xl = x;
    xr = x - a * gradient(x);
    phi = (3 - sqrt(5)) / 2;

    it = 0;
    while norm(xr - xl) > 10^(-6) && it < maxit
        x1 = phi * xr + (1 - phi) * xl;
        x2 = phi * xl + (1 - phi) * xr;
        if  f(x1) >  f(x2)
            xl = x1;
        else
            xr = x2;
        end
        it = it + 1;
    end
   xtemp = (xr + xl) / 2;
   
    iter = iter + 1;
    x = xtemp;
    
end
disp('exact line:')
disp('x = ')
disp(x)
disp('the number of iterations')
disp(iter)
