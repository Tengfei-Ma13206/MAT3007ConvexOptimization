p = [0.75; 0.35; 0.40; 0.75; 0.65]
q = [10; 5; 10; 10; 5]
cvx_begin
    variables x(5) w
    maximize (w - p'*x)
    subject to
    x(1) + x(3) + x(4) >= w
    x(1) + x(4) + x(5) >= w
    x(1) + x(3) + x(4) >= w
    x(2) + x(4) + x(5) >= w
    x(2) + x(3) + x(5) >= w
    x >= 0
    x <= q
cvx_end