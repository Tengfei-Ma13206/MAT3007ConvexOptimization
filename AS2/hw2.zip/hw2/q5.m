cvx_begin
    variables y1 y2 r
    maximize r
    subject to
    (y1 - y2 + 6)/sqrt(2) >= r
    (-y1 - y2 + 18)/sqrt(2) >= r
    (y1 + y2 - 1)/sqrt(2) >= r
    (-y1 + y2 + 7)/sqrt(2) >= r
    10 - y2 >= r
    y2 >= r
    y1 >= r
    11 - y1 >= r
    r >= 0
cvx_end