%% LP relaxation
cvx_begin
variables x_B x_AB x_BC x_AD x_BE x_BF x_CG x_DH x_EH x_GJ x_HI x_FG
    minimize (x_B + x_AB + x_BC + x_AD + x_BE + x_BF + x_CG + x_DH + x_EH + x_GJ + x_HI + x_FG)
    subject to
        x_AD + x_AB >= 1
        x_AB + x_B + x_BC + x_BF + x_BE >= 1
        x_BC + x_CG >= 1
        x_AD + x_DH >= 1
        x_BE + x_EH >= 1
        x_BF + x_FG >= 1
        x_CG + x_GJ + x_FG >= 1
        x_DH + x_EH + x_HI >= 1
        x_HI >= 1
        x_GJ >= 1
        0 <= x_B
        0 <= x_AB
        0 <= x_BC
        0 <= x_AD
        0 <= x_BE
        0 <= x_BF
        0 <= x_CG
        0 <= x_DH
        0 <= x_EH
        0 <= x_GJ
        0 <= x_HI
        0 <= x_FG
        1 >= x_B
        1 >= x_AB
        1 >= x_BC
        1 >= x_AD
        1 >= x_BE
        1 >= x_BF
        1 >= x_CG
        1 >= x_DH
        1 >= x_EH
        1 >= x_GJ
        1 >= x_HI
        1 >= x_FG
cvx_end
x_B
x_AB
x_BC
x_AD
x_BE
x_BF
x_CG
x_GJ
x_DH
x_EH
x_HI
x_FG