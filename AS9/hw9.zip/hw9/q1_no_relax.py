# no relax
minGuards = 12
for x_B in (0,1):
    for x_AB in (0,1):
        for x_BC in (0, 1):
            for x_AD in (0, 1):
                for x_BE in (0, 1):
                    for x_BF in (0, 1):
                        for x_CG in (0, 1):
                            for x_DH in (0, 1):
                                for x_EH in (0, 1):
                                    for x_GJ in (0, 1):
                                        for x_HI in (0, 1):
                                            for x_FG in (0, 1):
                                                if x_AD + x_AB >= 1 and x_AB + x_B + x_BC + x_BF + x_BE >= 1 and x_BC + x_CG >= 1 and \
                                                    x_AD + x_DH >= 1 and x_BE + x_EH >= 1 and x_BF + x_FG >= 1 and x_CG + x_GJ + x_FG >= 1 and\
                                                    x_DH + x_EH + x_HI >= 1 and x_HI >= 1 and x_GJ >= 1:
                                                    if minGuards > x_B + x_AB + x_BC + x_AD + x_BE + x_BF + x_CG + x_DH + x_EH + x_GJ + x_HI + x_FG:
                                                        minGuards = x_B + x_AB + x_BC + x_AD + x_BE + x_BF + x_CG + x_DH + x_EH + x_GJ + x_HI + x_FG
                                                        x_B_opt = x_B
                                                        x_AB_opt = x_AB
                                                        x_BC_opt = x_BC
                                                        x_AD_opt = x_AD
                                                        x_BE_opt = x_BE
                                                        x_BF_opt = x_BF
                                                        x_CG_opt = x_CG
                                                        x_DH_opt = x_DH
                                                        x_EH_opt = x_EH
                                                        x_GJ_opt = x_GJ
                                                        x_HI_opt = x_HI
                                                        x_FG_opt = x_FG
print("minGuards = ",minGuards)
print("x_B_opt = ", x_B_opt)
print("x_AB_opt = ",x_AB_opt)
print("x_BC_opt = ",x_BC_opt)
print("x_AD_opt = ",x_AD_opt)
print("x_BE_opt = ",x_BE_opt)
print("x_BF_opt = ",x_BF_opt)
print("x_CG_opt = ",x_CG_opt)
print("x_DH_opt = ",x_DH_opt)
print("x_EH_opt = ",x_EH_opt)
print("x_GJ_opt = ",x_GJ_opt)
print("x_HI_opt = ",x_HI_opt)
print("x_FG_opt = ",x_FG_opt)

