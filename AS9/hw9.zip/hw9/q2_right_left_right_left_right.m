cvx_begin
variables x y
maximize (17*x+12*y)
subject to
    10*x + 7*y <= 40
    x + y <= 5
    x >= 0
    y >= 0

    x >= 2
    y <= 2
    x >= 3
    y <= 1
    x >= 4
cvx_end
x
y